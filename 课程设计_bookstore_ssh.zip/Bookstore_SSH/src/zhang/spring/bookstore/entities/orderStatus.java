package zhang.spring.bookstore.entities;
//����״̬
public class orderStatus {
	
	//״̬id
	private Integer statuId;
	//״̬����
	private String statuName;
	public Integer getStatuId() {
		return statuId;
	}
	public void setStatuId(Integer statuId) {
		this.statuId = statuId;
	}
	public String getStatuName() {
		return statuName;
	}
	public void setStatuName(String statuName) {
		this.statuName = statuName;
	}
	public orderStatus() {
		// TODO Auto-generated constructor stub
	}
	
	
	
}
